<?php

define('MYSQL_HOST', 'localhost');
define('MYSQL_LOGIN', 'drop_db');
define('MYSQL_PASSWORD', 'dPBC5EWtMHRQA7Jb');
define('MYSQL_DB', 'drop_db');

define('USER', 'lookbehind');
define('PASS', '9fcd49c09984f4960da6cb32b7e755a9');
