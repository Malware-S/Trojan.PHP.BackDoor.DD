<?php if(!defined('__CP__'))die();
?>