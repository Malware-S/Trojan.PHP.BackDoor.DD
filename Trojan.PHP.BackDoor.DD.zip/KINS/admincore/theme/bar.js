var vestibar_rssString ="<?xml version=\"1.0\" encoding=\"utf-8\"?><rss version=\"2.0\" xmlns:yandex=\"http://www.yandex.ru\"><channel><encoding>utf-8</encoding><title>\u0412\u0415\u0421\u0422\u0418</title><about>http://www.vesti.ru/</about><link>http://www.vesti.ru</link>        <item><title>\u0420\u043e\u0441\u0441\u0438\u044f \u0438 \u0423\u043a\u0440\u0430\u0438\u043d\u0430: \u0441\u043e\u0432\u043c\u0435\u0441\u0442\u043d\u044b\u0435 \u043f\u0435\u0440\u0441\u043f\u0435\u043a\u0442\u0438\u0432\u044b</title><pubDate>Sat, 25 Aug 2012 20:01:00 +0400</pubDate><tag>\u0433\u043b\u0430\u0432\u043d\u0430\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149179.mp4?auth=vh&amp;vid=149179&amp;start=60.2&amp;end=237.72\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889304</link></item><item><title>\u0427\u0438\u0441\u043b\u043e \u0436\u0435\u0440\u0442\u0432 \u0414\u0422\u041f \u0432 \u041a\u0430\u043b\u0443\u0436\u0441\u043a\u043e\u0439 \u043e\u0431\u043b\u0430\u0441\u0442\u0438 \u0432\u043e\u0437\u0440\u043e\u0441\u043b\u043e</title><pubDate>Sat, 25 Aug 2012 23:10:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149160.mp4?auth=vh&amp;vid=149160&amp;start=0&amp;end=52\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889369</link></item><item><title>\u0421\u043a\u043e\u043d\u0447\u0430\u043b\u0441\u044f \u043b\u0435\u0433\u0435\u043d\u0434\u0430\u0440\u043d\u044b\u0439 \u0430\u0441\u0442\u0440\u043e\u043d\u0430\u0432\u0442 \u041d\u0438\u043b \u0410\u0440\u043c\u0441\u0442\u0440\u043e\u043d\u0433</title><pubDate>Sat, 25 Aug 2012 23:17:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889371</link></item><item><title>\u041f\u044f\u0442\u044b\u0439 \u0440\u0435\u0431\u0435\u043d\u043e\u043a \u043e\u043a\u0430\u0437\u0430\u043b\u0441\u044f \u043b\u0438\u0448\u043d\u0438\u043c</title><pubDate>Sat, 25 Aug 2012 20:03:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149179.mp4?auth=vh&amp;vid=149179&amp;start=263.64&amp;end=451.4\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889263</link></item><item><title>\u0420\u041f\u0426 \u043f\u0440\u0438\u0440\u0430\u0432\u043d\u044f\u043b\u0430 \u043e\u0441\u043a\u0432\u0435\u0440\u043d\u0438\u0442\u0435\u043b\u0435\u0439 \u043a\u0440\u0435\u0441\u0442\u043e\u0432 \u043a \u0410\u043d\u0434\u0435\u0440\u0441\u0443 \u0411\u0440\u0435\u0439\u0432\u0438\u043a\u0443</title><pubDate>Sat, 25 Aug 2012 19:54:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149179.mp4?auth=vh&amp;vid=149179&amp;start=1022.44&amp;end=1080.84\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889322</link></item><item><title>\u041f\u043e\u0441\u0442\u0440\u0430\u0434\u0430\u0432\u0448\u0438\u0435 \u043d\u0430 \u041a\u0438\u043f\u0440\u0435 \u0438 \u0432 \u041a\u0440\u044b\u043c\u0443 \u0440\u043e\u0441\u0441\u0438\u044f\u043d\u0435 \u0434\u043e\u0441\u0442\u0430\u0432\u043b\u0435\u043d\u044b \u0432 \u041c\u043e\u0441\u043a\u0432\u0443</title><pubDate>Sat, 25 Aug 2012 21:51:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889345</link></item><item><title>\u0412 \u0412\u0435\u043d\u0435\u0441\u0443\u044d\u043b\u0435 \u043e\u0431\u044a\u044f\u0432\u043b\u0435\u043d \u0442\u0440\u0435\u0445\u0434\u043d\u0435\u0432\u043d\u044b\u0439 \u0442\u0440\u0430\u0443\u0440</title><pubDate>Sun, 26 Aug 2012 00:06:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149140.mp4?auth=vh&amp;vid=149140&amp;start=0&amp;end=32\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889383</link></item><item><title>\u041d\u0430\u043f\u0430\u0434\u0435\u043d\u0438\u0435 \u043d\u0430 \u043f\u043e\u043b\u0438\u0446\u0435\u0439\u0441\u043a\u0438\u0445 \u0432 \u0414\u0430\u0433\u0435\u0441\u0442\u0430\u043d\u0435: \u043e\u0434\u0438\u043d \u043f\u043e\u0433\u0438\u0431\u0448\u0438\u0439, \u0442\u0440\u043e\u0435 \u0440\u0430\u043d\u0435\u043d\u044b\u0445</title><pubDate>Sun, 26 Aug 2012 00:48:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889396</link></item><item><title>\u0414\u0432\u043e\u0435 \u0441\u0442\u0430\u043b\u0438 \u0436\u0435\u0440\u0442\u0432\u0430\u043c\u0438 \u0430\u0432\u0438\u0430\u043a\u0430\u0442\u0430\u0441\u0442\u0440\u043e\u0444\u044b \u0432 \u041f\u043e\u0434\u043c\u043e\u0441\u043a\u043e\u0432\u044c\u0435</title><pubDate>Sat, 25 Aug 2012 20:43:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889335</link></item><item><title>\u041f\u0430\u0442\u0440\u0438\u0430\u0440\u0445: \u0432\u0435\u0440\u0430 \u0438 \u043d\u0430\u0446\u0438\u043e\u043d\u0430\u043b\u044c\u043d\u043e\u0441\u0442\u044c \u043d\u0435 \u0434\u043e\u043b\u0436\u043d\u044b \u0440\u0430\u0437\u0434\u0435\u043b\u044f\u0442\u044c \u043d\u0430\u0440\u043e\u0434\u044b \u0420\u043e\u0441\u0441\u0438\u0438</title><pubDate>Sat, 25 Aug 2012 20:20:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149179.mp4?auth=vh&amp;vid=149179&amp;start=1080.84&amp;end=1267.24\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889271</link></item><item><title>\u041d\u0430 \u043f\u043b\u043e\u0449\u0430\u0434\u0438 \u0422\u0430\u0445\u0440\u0438\u0440 \u043e\u043f\u044f\u0442\u044c \u0432\u0441\u0435 \u043d\u0435\u0441\u043f\u043e\u043a\u043e\u0439\u043d\u043e</title><pubDate>Sat, 25 Aug 2012 20:13:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149179.mp4?auth=vh&amp;vid=149179&amp;start=764.12&amp;end=936.92\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889269</link></item><item><title>\u041a \u042f\u043f\u043e\u043d\u0438\u0438 \u043f\u0440\u0438\u0431\u043b\u0438\u0436\u0430\u0435\u0442\u0441\u044f \u0441\u0443\u043f\u0435\u0440\u0442\u0430\u0439\u0444\u0443\u043d</title><pubDate>Sat, 25 Aug 2012 15:13:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149139.mp4?auth=vh&amp;vid=149139&amp;start=0&amp;end=111\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889216</link></item><item><title>\u0416\u0438\u0442\u0435\u043b\u0435\u0439 \u0421\u0435\u0440\u0431\u0438\u0438 \u044d\u0432\u0430\u043a\u0443\u0438\u0440\u0443\u044e\u0442 \u0438\u0437-\u0437\u0430 \u043b\u0435\u0441\u043d\u044b\u0445 \u043f\u043e\u0436\u0430\u0440\u043e\u0432</title><pubDate>Sat, 25 Aug 2012 21:40:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149161.mp4?auth=vh&amp;vid=149161&amp;start=0&amp;end=59\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889342</link></item><item><title>Apple: \u043f\u043e\u0431\u0435\u0434\u0430 \u0438 \u043c\u0438\u043b\u043b\u0438\u0430\u0440\u0434</title><pubDate>Sat, 25 Aug 2012 20:08:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149179.mp4?auth=vh&amp;vid=149179&amp;start=451.4&amp;end=601.8\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889265</link></item><item><title>\u0414\u0435\u043d\u044c \u043f\u0430\u043c\u044f\u0442\u0438 \u042f\u043d\u0430 \u0410\u0440\u043b\u0430\u0437\u043e\u0440\u043e\u0432\u0430</title><pubDate>Sun, 26 Aug 2012 01:36:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889407</link></item><item><title>\u0411\u0440\u0435\u0439\u0432\u0438\u043a\u0443 \u0441\u043c\u044f\u0433\u0447\u0430\u044e\u0442 \u0443\u0441\u043b\u043e\u0432\u0438\u044f \u0441\u043e\u0434\u0435\u0440\u0436\u0430\u043d\u0438\u044f \u0432 \u0442\u044e\u0440\u044c\u043c\u0435</title><pubDate>Sun, 26 Aug 2012 01:23:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889404</link></item><item><title>\u0421\u043e\u0442\u043d\u0438 \u0442\u044b\u0441\u044f\u0447 \u043b\u044e\u0434\u0435\u0439 \u043f\u0440\u043e\u0439\u0434\u0443\u0442 \u043a\u0430\u0440\u043d\u0430\u0432\u0430\u043b\u044c\u043d\u044b\u043c \u0448\u0435\u0441\u0442\u0432\u0438\u0435\u043c \u043f\u043e \u041b\u043e\u043d\u0434\u043e\u043d\u0443</title><pubDate>Sun, 26 Aug 2012 00:22:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889390</link></item><item><title>\u0410\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044c \u043f\u0440\u043e\u0431\u0438\u043b \u043e\u0433\u0440\u0430\u0436\u0434\u0435\u043d\u0438\u0435 \u0438 \u0440\u0443\u0445\u043d\u0443\u043b \u0432 \u041c\u043e\u0441\u043a\u0432\u0443-\u0440\u0435\u043a\u0443</title><pubDate>Sat, 25 Aug 2012 21:11:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889337</link></item><item><title>\u041c\u0430\u0442\u0447\u0438 &quot;\u041c\u0430\u043d\u0447\u0435\u0441\u0442\u0435\u0440 \u0421\u0438\u0442\u0438&quot; \u0438 &quot;\u0410\u0440\u0441\u0435\u043d\u0430\u043b\u0430&quot; \u043d\u0430 \u0412\u0435\u0441\u0442\u044f\u0445.Ru</title><pubDate>Sat, 25 Aug 2012 20:41:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889326</link></item><item><title>\u0412 \u0422\u0443\u0430\u043f\u0441\u0438\u043d\u0441\u043a\u043e\u043c \u0440\u0430\u0439\u043e\u043d\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u0430 \u0432\u0430\u043a\u0446\u0438\u043d\u0430\u0446\u0438\u044f \u043d\u0430\u0441\u0435\u043b\u0435\u043d\u0438\u044f</title><pubDate>Sat, 25 Aug 2012 20:32:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889333</link></item><item><title>\u041e\u0434\u043d\u0430 \u0430\u0431\u0441\u043e\u043b\u044e\u0442\u043d\u043e \u0437\u0434\u043e\u0440\u043e\u0432\u0430\u044f \u0434\u0435\u0440\u0435\u0432\u043d\u044f</title><pubDate>Sat, 25 Aug 2012 20:21:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149179.mp4?auth=vh&amp;vid=149179&amp;start=1365.16&amp;end=1539.08\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889272</link></item><item><title>\u0413\u0440\u0435\u0446\u0438\u0438 \u043d\u0435 \u043d\u0430 \u0447\u0435\u043c \u044d\u043a\u043e\u043d\u043e\u043c\u0438\u0442\u044c</title><pubDate>Sat, 25 Aug 2012 20:11:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149179.mp4?auth=vh&amp;vid=149179&amp;start=601.8&amp;end=764.12\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889268</link></item><item><title>\u0424\u0443\u0442\u0431\u043e\u043b. &quot;\u0420\u0443\u0431\u0438\u043d&quot; \u043e\u0431\u044b\u0433\u0440\u0430\u043b &quot;\u0417\u0435\u043d\u0438\u0442&quot; \u0432 \u0434\u0435\u043d\u044c \u0440\u043e\u0436\u0434\u0435\u043d\u0438\u044f \u0411\u0435\u0440\u0434\u044b\u0435\u0432\u0430</title><pubDate>Sat, 25 Aug 2012 18:20:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889292</link></item><item><title>\u0421\u0431\u0435\u0436\u0430\u0432\u0448\u0438\u0439 \u0442\u0438\u0433\u0440 \u0440\u0430\u0441\u0442\u0435\u0440\u0437\u0430\u043b \u0440\u0430\u0431\u043e\u0442\u043d\u0438\u0446\u0443 \u0437\u043e\u043e\u043f\u0430\u0440\u043a\u0430 \u041a\u0435\u043b\u044c\u043d\u0430</title><pubDate>Sat, 25 Aug 2012 16:29:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149179.mp4?auth=vh&amp;vid=149179&amp;start=936.92&amp;end=965.12\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889247</link></item><item><title>\u041c\u0430\u0448\u0438\u043d\u0430 \u0441 \u0441\u043e\u043b\u0438\u0441\u0442\u043e\u043c &quot;\u041b\u0430\u0441\u043a\u043e\u0432\u043e\u0433\u043e \u043c\u0430\u044f&quot; \u043c\u043e\u0433\u043b\u0430 \u0432\u044b\u0435\u0445\u0430\u0442\u044c \u043d\u0430 \u0432\u0441\u0442\u0440\u0435\u0447\u043a\u0443</title><pubDate>Sat, 25 Aug 2012 14:32:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=889210</link></item><item><title>\u0412 \u0422\u043e\u043b\u044c\u044f\u0442\u0442\u0438 \u0432 \u0446\u0438\u0440\u043a\u0435-\u0448\u0430\u043f\u0438\u0442\u043e \u0433\u0435\u043f\u0430\u0440\u0434 \u043d\u0430\u043f\u0430\u043b \u043d\u0430 \u0434\u0435\u0442\u0435\u0439</title><pubDate>Sat, 25 Aug 2012 11:33:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149061.mp4?auth=vh&amp;vid=149061&amp;start=124.48&amp;end=152.96\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889136</link></item><item><title>\u041a\u043e\u043b\u043b\u0435\u043a\u0446\u0438\u043e\u043d\u0435\u0440 \u0410\u043d\u0434\u0440\u0435\u0439 \u0412\u0430\u0441\u0438\u043b\u044c\u0435\u0432 \u0441\u0443\u0434\u0438\u0442\u0441\u044f \u0441 \u0420\u0443\u0441\u0441\u043a\u0438\u043c \u043c\u0443\u0437\u0435\u0435\u043c</title><pubDate>Sat, 25 Aug 2012 06:47:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><link>http://www.vesti.ru/doc.html?id=888913</link></item><item><title>\u0421\u0442\u0440\u0435\u043b\u044c\u0431\u0430 \u043d\u0430 \u041c\u0430\u043d\u0445\u044d\u0442\u0442\u0435\u043d\u0435: \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u0430 \u043b\u0438\u0447\u043d\u043e\u0441\u0442\u044c \u043f\u0440\u0435\u0441\u0442\u0443\u043f\u043d\u0438\u043a\u0430</title><pubDate>Sat, 25 Aug 2012 01:25:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/148966.mp4?auth=vh&amp;vid=148966&amp;start=0&amp;end=167\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=888674</link></item><item><title>\u0415\u0436\u0435\u043d\u0435\u0434\u0435\u043b\u044c\u043d\u0430\u044f \u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u0430 \u0412\u0435\u0441\u0442\u0438.net \u043e\u0442 25 \u0430\u0432\u0433\u0443\u0441\u0442\u0430 2012 \u0433\u043e\u0434\u0430</title><pubDate>Sat, 25 Aug 2012 12:13:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149023.mp4?auth=vh&amp;vid=149023&amp;start=0&amp;end=1259\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=888598</link></item><item><title>\u041a\u043e\u0441\u043c\u043e\u043d\u0430\u0432\u0442\u044b \u0432 \u043f\u0443\u0441\u0442\u044b\u043d\u0435 </title><pubDate>Sat, 25 Aug 2012 10:34:00 +0400</pubDate><tag>\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149043.mp4?auth=vh&amp;vid=149043&amp;start=0&amp;end=505\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=888603</link></item><item><title>\u0413\u0440\u0435\u0446\u0438\u0438 \u043d\u0435 \u043d\u0430 \u0447\u0435\u043c \u044d\u043a\u043e\u043d\u043e\u043c\u0438\u0442\u044c</title><pubDate>Sat, 25 Aug 2012 20:11:00 +0400</pubDate><tag>\u044d\u043a\u043e\u043d\u043e\u043c\u0438\u043a\u0430</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149179.mp4?auth=vh&amp;vid=149179&amp;start=601.8&amp;end=764.12\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889268</link></item><item><title>\u0420\u043e\u0441\u0441\u0438\u044f \u0438 \u0423\u043a\u0440\u0430\u0438\u043d\u0430: \u0441\u043e\u0432\u043c\u0435\u0441\u0442\u043d\u044b\u0435 \u043f\u0435\u0440\u0441\u043f\u0435\u043a\u0442\u0438\u0432\u044b</title><pubDate>Sat, 25 Aug 2012 20:01:00 +0400</pubDate><tag>\u044d\u043a\u043e\u043d\u043e\u043c\u0438\u043a\u0430</tag><enclosure url=\"http://www.vgtrk.cdnvideo.ru/_cdn_auth/secure/v/vh/mp4/medium/149179.mp4?auth=vh&amp;vid=149179&amp;start=60.2&amp;end=237.72\" type=\"video/mp4\" /><link>http://www.vesti.ru/doc.html?id=889304</link></item><item><title>\u0420\u0435\u0448\u0435\u043d\u0438\u0435 \u043e \u043f\u043e\u043c\u043e\u0449\u0438 \u0413\u0440\u0435\u0446\u0438\u0438 \u0431\u0443\u0434\u0435\u0442 \u043f\u0440\u0438\u043d\u044f\u0442\u043e \u043f\u043e\u0441\u043b\u0435 \u0434\u043e\u043a\u043b\u0430\u0434\u0430 &quot;\u0442\u0440\u043e\u0439\u043a\u0438&quot; </title><pubDate>Sat, 25 Aug 2012 16:31:00 +0400</pubDate><tag>\u044d\u043a\u043e\u043d\u043e\u043c\u0438\u043a\u0430</tag><link>http://www.vesti.ru/doc.html?id=889242</link></item><item><title>\u041a\u0438\u043a\u0431\u043e\u043a\u0441\u0435\u0440 \u0420\u043e\u043c\u0430\u043d &quot;\u0413\u0440\u043e\u043c&quot; \u041c\u0430\u0438\u043b\u043e\u0432 \u043e\u0434\u043e\u043b\u0435\u043b \u0414\u0435\u043d\u0438\u0441\u0430 \u041b\u0430\u0440\u0447\u0435\u043d\u043a\u043e</title><pubDate>Sat, 25 Aug 2012 20:59:00 +0400</pubDate><tag>\u0441\u043f\u043e\u0440\u0442</tag><link>http://www.vesti.ru/doc.html?id=889338</link></item><item><title>\u041c\u0430\u0442\u0447\u0438 &quot;\u041c\u0430\u043d\u0447\u0435\u0441\u0442\u0435\u0440 \u0421\u0438\u0442\u0438&quot; \u0438 &quot;\u0410\u0440\u0441\u0435\u043d\u0430\u043b\u0430&quot; \u043d\u0430 \u0412\u0435\u0441\u0442\u044f\u0445.Ru</title><pubDate>Sat, 25 Aug 2012 20:41:00 +0400</pubDate><tag>\u0441\u043f\u043e\u0440\u0442</tag><link>http://www.vesti.ru/doc.html?id=889326</link></item><item><title>\u0424\u0443\u0442\u0431\u043e\u043b. &quot;\u0422\u0435\u0440\u0435\u043a&quot; \u043e\u0431\u044b\u0433\u0440\u0430\u043b &quot;\u0421\u043f\u0430\u0440\u0442\u0430\u043a&quot; \u0438 \u0434\u043e\u0433\u043d\u0430\u043b &quot;\u0417\u0435\u043d\u0438\u0442&quot;</title><pubDate>Sat, 25 Aug 2012 20:29:00 +0400</pubDate><tag>\u0441\u043f\u043e\u0440\u0442</tag><link>http://www.vesti.ru/doc.html?id=889334</link></item><item><title>\u0423\u0448\u0435\u043b \u0438\u0437 \u0436\u0438\u0437\u043d\u0438 \u043b\u0435\u0433\u0435\u043d\u0434\u0430\u0440\u043d\u044b\u0439 \u0444\u0443\u0442\u0431\u043e\u043b\u0438\u0441\u0442 \u0424\u0435\u043b\u0438\u043a\u0441</title><pubDate>Sat, 25 Aug 2012 20:20:00 +0400</pubDate><tag>\u0441\u043f\u043e\u0440\u0442</tag><link>http://www.vesti.ru/doc.html?id=889329</link></item><item><title>\u0412 Prior Design \u0432 \u043e\u0447\u0435\u0440\u0435\u0434\u043d\u043e\u0439 \u0440\u0430\u0437 \u043e\u0431\u043b\u0430\u0433\u043e\u0440\u043e\u0434\u0438\u043b\u0438 Mercedes-Benz CL</title><pubDate>Fri, 24 Aug 2012 00:00:00 +0400</pubDate><tag>\u0430\u0432\u0442\u043e.\u0432\u0435\u0441\u0442\u0438.ru</tag><link>http://auto.vesti.ru/doc.html?id=471113</link></item><item><title>Hyundai \u043f\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u0438\u0442 \u0432 \u041c\u043e\u0441\u043a\u0432\u0435 \u0431\u0440\u043e\u043d\u0438\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0439 \u043b\u0438\u043c\u0443\u0437\u0438\u043d Equus   </title><pubDate>Fri, 24 Aug 2012 00:00:00 +0400</pubDate><tag>\u0430\u0432\u0442\u043e.\u0432\u0435\u0441\u0442\u0438.ru</tag><link>http://auto.vesti.ru/doc.html?id=471033</link></item><item><title>Audi \u0432\u043e\u0437\u0440\u043e\u0434\u0438\u0442 \u0441\u043f\u043e\u0440\u0442\u043a\u0430\u0440 Quattro \u0432 2015 \u0433\u043e\u0434\u0443</title><pubDate>Fri, 24 Aug 2012 00:00:00 +0400</pubDate><tag>\u0430\u0432\u0442\u043e.\u0432\u0435\u0441\u0442\u0438.ru</tag><link>http://auto.vesti.ru/doc.html?id=471053</link></item><item><title>\u0411\u0443\u0434\u0443\u0449\u0435\u0435 \u0413\u0440\u0430\u043d \u041f\u0440\u0438 \u0424\u0440\u0430\u043d\u0446\u0438\u0438 \u043e\u0441\u0442\u0430\u0435\u0442\u0441\u044f \u043f\u043e\u0434 \u0432\u043e\u043f\u0440\u043e\u0441\u043e\u043c</title><pubDate>Fri, 24 Aug 2012 00:00:00 +0400</pubDate><tag>\u0430\u0432\u0442\u043e.\u0432\u0435\u0441\u0442\u0438.ru</tag><link>http://auto.vesti.ru/doc.html?id=471093</link></item><item><title>\u041d\u043e\u0432\u0430\u044f BMW M3 \u043c\u043d\u043e\u0433\u043e\u0435 \u043f\u043e\u0437\u0430\u0438\u043c\u0441\u0442\u0432\u0443\u0435\u0442 \u0443 \u0441\u0435\u0434\u0430\u043d\u0430 \u041c5</title><pubDate>Fri, 24 Aug 2012 00:00:00 +0400</pubDate><tag>\u0430\u0432\u0442\u043e.\u0432\u0435\u0441\u0442\u0438.ru</tag><link>http://auto.vesti.ru/doc.html?id=471074</link></item></channel></rss>";
var vestibar_base = "http://toolbar.vesti.ru/vestibar/i/";

// init stylesheet

var headID = document.getElementsByTagName("head")[0];
var cssNode = document.createElement('link');
cssNode.type = 'text/css';
cssNode.rel = 'stylesheet';
cssNode.href = vestibar_base+'style.css';
cssNode.media = 'screen';
headID.appendChild(cssNode);

// init misc stuff

var vestibar_news = new Array();
var vestibar_news_index = 0;

var vestibar_shift = vestibar_getCookie("vestibar_shift");
var vestibar_update = vestibar_getCookie("vestibar_update");
var tm_s, tm_u;

if(vestibar_shift<1) vestibar_shift = 5000;
if(vestibar_update<1) vestibar_update = 0;

if(navigator.appName=="Microsoft Internet Explorer") {
	var vestibar_href="(::Link::)";
	var vestibar_link_prefix = "href='";
	var vestibar_link_suffix = "&toolbar=web'";
	var vestibar_title_prefix = "";
	var vestibar_title_suffix = ""
} else {
	var vestibar_href="href='(::Link::)'";
	var vestibar_link_prefix = "";
	var vestibar_link_suffix = "&toolbar=web";
	var vestibar_title_prefix = "title='";
	var vestibar_title_suffix = "'";
}

var can_close = true;

var vestibar_code = "<table width='100%' border='1' cellspacing='2' cellpadding='0' id='vesti_informer'><tr><td width='1%'><a title='Vesti.ru' href='http://www.vesti.ru/?toolbar=web'><img src='"+vestibar_base+"vesti.gif' width='75' height='20' border='0'></a></td><td width='40%' id='vestibar_main'><span id='rssBodyFirstTemplate'><a "+vestibar_title_prefix+"(::Title2::)"+vestibar_title_suffix+" target='_blank' "+vestibar_href+">(::Title::)</a>(::Video::)</span></td><td width='60%' id='vestibar_other'><span id='rssBody2Template'><a target='_blank' "+vestibar_href+" "+vestibar_title_prefix+"(::Title2::)"+vestibar_title_suffix+">(::Title::)</a>(::Video::)</span></td><td width='1%' id='vestibar_dropdown'><ul id='informer_news'><span id='rssBodyTemplate'><li class='(::Class::)'><a onFocus='can_close=false' onBlur='can_close=true; informer_menu(0)' target='_blank' "+vestibar_href+" "+vestibar_title_prefix+"(::Title2::)"+vestibar_title_suffix+">(::Title::)</a>(::Video::)</li></span></ul><a href='javascript:void(0)' onClick='informer_menu(1);' onBlur='informer_menu(0)'><img src='"+vestibar_base+"arrow.gif' width='21' height='18' border='0' title='\u0420\u0430\u0437\u0432\u0435\u0440\u043d\u0443\u0442\u044c \u0432\u0441\u0435 \u043d\u043e\u0432\u043e\u0441\u0442\u0438'></a></td><td width='1%' id='vestibar_settings'><ul id='informer_settings'><li><table width='100%' border='0' cellspacing='0' cellpadding='0'><tr><td colspan='2'><b>\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0438\u043d\u0444\u043e\u0440\u043c\u0435\u0440\u0430</b></td></tr><tr><td>\u041e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u043b\u0435\u043d\u0442\u044b \u043a\u0430\u0436\u0434\u044b\u0435</td><td><select name='vestibar_update' id='vestibar_update' onChange='vestibar_apply()'><option value='300000'>5 \u043c\u0438\u043d\u0443\u0442</option><option value='600000'>10 \u043c\u0438\u043d\u0443\u0442</option><option value='1800000'>30 \u043c\u0438\u043d\u0443\u0442</option><option value='3600000'>60 \u043c\u0438\u043d\u0443\u0442</option><option value='0'>(\u043d\u0435 \u043e\u0431\u043d\u043e\u0432\u043b\u044f\u0442\u044c)</option></select></td></tr><tr><td>\u041b\u0438\u0441\u0442\u0430\u0442\u044c \u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u043a\u0430\u0436\u0434\u044b\u0435</td><td><select name='vestibar_shift' id='vestibar_shift' onChange='vestibar_apply()'><option value='5000'>5 \u0441\u0435\u043a\u0443\u043d\u0434</option><option value='10000'>10 \u0441\u0435\u043a\u0443\u043d\u0434</option><option value='30000'>30 \u0441\u0435\u043a\u0443\u043d\u0434</option></select></td></tr><tr><td>&nbsp;</td><td align='right'><a href='javascript:void(0)' onClick='informer_settings_box()'>\u0437\u0430\u043a\u0440\u044b\u0442\u044c</a></td></tr></table></li></ul><a href='javascript:void(0)' onClick='informer_settings_box()'><img src='"+vestibar_base+"settings.gif' title='\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438' width='22' height='20' border='0'></a></td><td width='1%'><a href='javascript:void(0)' onClick=\"vestibar_video_window('http://www.vesti.ru/video1.asx?vid=onair', '\u041f\u0440\u044f\u043c\u043e\u0439 \u044d\u0444\u0438\u0440')\"><img src='"+vestibar_base+"live.gif' title='\u041f\u0440\u044f\u043c\u043e\u0439 \u044d\u0444\u0438\u0440' width='81' height='20' border='0'></a></td></tr></table>";

//=====================================================================================

if(typeof(DOMParser) == 'undefined') {
 DOMParser = function() {}
 DOMParser.prototype.parseFromString = function(str, contentType) {
  if(typeof(ActiveXObject) != 'undefined') {
   var xmldata = new ActiveXObject('MSXML.DomDocument');
   xmldata.async = false;
   xmldata.loadXML(str);
   return xmldata;
  } else if(typeof(XMLHttpRequest) != 'undefined') {
   var xmldata = new XMLHttpRequest;
   if(!contentType) {
    contentType = 'application/xml';
   }
   xmldata.open('GET', 'data:' + contentType + ';charset=utf-8,' + encodeURIComponent(str), false);
   if(xmldata.overrideMimeType) {
    xmldata.overrideMimeType(contentType);
   }
   xmldata.send(null);
   return xmldata.responseXML;
  }
 }
}

//=====================================================================================

function vestibar_getCookie(name) {
        var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

//=====================================================================================

function vestibar_setCookie(name, value, days) {
	var date = new Date();
	if(!days) days = 150;
	date.setTime(date.getTime()+(days*24*60*60*1000));
	var expires = "; expires="+date.toGMTString();

	document.cookie = name+"="+value+expires+"; path=/";
}

//=====================================================================================

function vestibar_eraseCookie(name) {
	vestibar_setCookie(name, "", -1);
}

//=====================================================================================

function vestibar_video_window(what, vtitle) {
	var wnd = window.open('', 'vestibar_video', 'width=320, height=285, resizable=yes, scrollbars=no');
	wnd.document.write("<html><head><title>"+unescape(vtitle)+"</title></head><body leftmargin=\"0\" topmargin=\"0\" marginwidth=\"0\" marginheight=\"0\"><object CLASSID=CLSID:22D6f312-B0F6-11D0-94AB-0080C74C7E95 codebase=\"http://www.microsoft.com/ntserver/netshow/download/en/nsmp2inf.cab#Version=5,1,51,415\" standby=\"Loading Microsoft Media Player components...\" type=\"application/x-oleobject\" width=\"320\" height=\"285\" id=\"pleywideo\"><param name=autostart value=true><param name=filename value=\""+what+"\"><param name=controltype value=true><param name=showdisplay value=false><param name=showcontrols value=true><param name=quality value=high><embed type=video/x-ms-asf-plugin pluginspage=\"http://www.microsoft.com/windows/mediaplayer/download/default.asp\" src=\""+what+"\" showdisplay=0 showcontrols=1 width=\"320\" height=\"285\" id=\"pleywideo\" autostart=1></embed></object></body></html>");
}

function vestibar_flv_window(what, vtitle) {
	var wnd = window.open('', 'vestibar_video', 'width=320, height=290, resizable=yes, scrollbars=no');
	var code = what.replace(".flv", "");
	code = code.substring(code.lastIndexOf("/")+1, code.length);
	wnd.document.write("<html><head><title>"+unescape(vtitle)+"</title></head><body leftmargin=\"0\" topmargin=\"0\" marginwidth=\"0\" marginheight=\"0\"><object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" codebase=\"http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0\" width=\"320\" height=\"290\" id=\"flvplayer\" align=\"middle\"><param name=\"allowScriptAccess\" value=\"sameDomain\" /><param name=\"movie\" value=\"http://sport.vesti.ru/i/flvplayer.swf?vid="+code+"&autostart=true\" /><param name=\"quality\" value=\"high\" /><param name=\"wmode\" value=\"transparent\" /><param name=\"devicefont\" value=\"true\" /><param name=\"bgcolor\" value=\"#000000\" /><param name=\"file\" value=\""+what+"\" /><embed src=\"http://sport.vesti.ru/i/flvplayer.swf?vid="+code+"&autostart=true\" quality=\"high\" wmode=\"transparent\" devicefont=\"true\" bgcolor=\"#000000\" width=\"320\" height=\"290\" name=\"flvplayer\" align=\"middle\" allowScriptAccess=\"sameDomain\" type=\"application/x-shockwave-flash\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" /></object></body></html>");
}

//=====================================================================================

function informer_settings_box() {
	var inf = document.getElementById('informer_settings');
	if(document.getElementById('informer_news').style.cssText!="") informer_menu();
	if(inf.style.cssText=="") inf.style.cssText = "display: block";
	else inf.style.cssText = "";
}

//=====================================================================================

function vestibar_apply() {
	vestibar_shift = parseInt(document.getElementById('vestibar_shift').options[document.getElementById('vestibar_shift').selectedIndex].value);
	vestibar_update = parseInt(document.getElementById('vestibar_update').options[document.getElementById('vestibar_update').selectedIndex].value);

	vestibar_setCookie("vestibar_shift", vestibar_shift.toString());
	vestibar_setCookie("vestibar_update", vestibar_update.toString());
	
	clearTimeout(tm_u);
	clearTimeout(tm_s);

	setTimeout("vestibar_news_show()", vestibar_shift);
	if(vestibar_update>0) setTimeout("vestibar_news_update()", vestibar_update);
}

//=====================================================================================

function informer_menu(st) {
	var inf = document.getElementById('informer_news');
	if(document.getElementById('informer_settings').style.cssText!="") informer_settings_box();
	if(inf.style.cssText==""&&st>0) {
		inf.style.cssText = "display: block";
	}
	else setTimeout('vestibar_close_menu()', 200);
}

function vestibar_close_menu() {
	var inf = document.getElementById('informer_news');
	if(can_close) {
		inf.style.cssText = "";
	}
}

//=====================================================================================

function vestibar_Replace(totalValue,oldValue,newValue)
{
	while(totalValue.indexOf(oldValue) > -1)
		totalValue=totalValue.replace(oldValue,newValue);
			return totalValue;
}

//=====================================================================================

function vestibar_getNode(TagName, node)
{
	var currentNode = (node == null) ? xmlDoc.getElementsByTagName(TagName) : 
					items[node].getElementsByTagName(TagName);
	if(currentNode.length > 0)
		return currentNode[0].firstChild.nodeValue;
}

//=====================================================================================

function vestibar_ReadRSS(rssFeed) 
{
	document.getElementById("vesti_informer").style.cssText = "display: none";
	
	// init settings
	
	var elem = document.getElementById('vestibar_update');
	for (var i=0; i<elem.options.length; i++) {
		if(elem.options[i].value==vestibar_update) elem.selectedIndex=i;
	}
	
	elem = document.getElementById('vestibar_shift');
	for (i=0; i<elem.options.length; i++) {
		if(elem.options[i].value==vestibar_shift) elem.selectedIndex=i;
	}
	
	// proceed with rss
	
	rssBodyFirst = document.getElementById('rssBodyFirstTemplate');
	rssBody = document.getElementById('rssBodyTemplate');
	rssBody2 = document.getElementById('rssBody2Template');

	var parser = new DOMParser();
	var xmlDoc = parser.parseFromString(rssFeed, "text/xml");
	items=xmlDoc.getElementsByTagName('item');
	vestibar_SetRSSTemplates();
	document.getElementById("vesti_informer").style.cssText = "";

}

//=====================================================================================

function vestibar_SetRSSTemplates()
{
	if (rssBody)
	{
		var buffer = "";
		var buffer2 = "";
		var tag = "";
		var sclass = "";
		var enclosure = null;
		var is_video = false;
		var video_file = "";
		var tp;
		var a_title = "";
		var a_title2 = "";
		var a_link = "";
		for(var i=0; i< items.length; i++) 
		{
			is_video = false;
			
			var a_link = vestibar_link_prefix+vestibar_getNode('link',i)+vestibar_link_suffix;
			
			var a_title = vestibar_Replace(vestibar_getNode('title',i), "'", "&quot;");
			a_title = vestibar_Replace(a_title, "\"", "&quot;");
			if(navigator.appName=="Microsoft Internet Explorer") a_title2=" title='"+a_title+"'";
			else a_title2 = a_title;
						
			var outputFirst = (document.all) ? vestibar_Replace(rssBodyFirst.innerHTML,"(::Link::)",a_link) : vestibar_Replace(rssBodyFirst.innerHTML,"%28::Link::%29", a_link);
			outputFirst = vestibar_Replace(outputFirst,"(::Title::)", a_title);
			outputFirst = vestibar_Replace(outputFirst,"(::Title2::)", a_title2);
			
			var output = (document.all) ? vestibar_Replace(rssBody.innerHTML,"(::Link::)", a_link) : vestibar_Replace(rssBody.innerHTML,"%28::Link::%29", a_link);
			
			output = vestibar_Replace(output,"(::Title::)", a_title);
			output = vestibar_Replace(output,"(::Title2::)", a_title2);
			
			var output2 = (document.all) ? vestibar_Replace(rssBody2.innerHTML,"(::Link::)",a_link) : vestibar_Replace(rssBody2.innerHTML,"%28::Link::%29",a_link);
			output2 = vestibar_Replace(output2,"(::Title::)",a_title);
			output2 = vestibar_Replace(output2,"(::Title2::)",a_title2);
			
			// check video
			enclosure = items[i].getElementsByTagName("enclosure");
			video_file = "";
			for (j=0; j<enclosure.length; j++) {
				tp = enclosure[j].getAttribute('type');
				if(tp.search('video')>=0) {
					is_video = true;
					video_file = enclosure[j].getAttribute('url');
				}
			}
			
			if(is_video) {
				if(video_file.search("flv")>=0) video_file = "<a class=\"video\" title=\"\u0421\u043c\u043e\u0442\u0440\u0435\u0442\u044c \u0432\u0438\u0434\u0435\u043e\" href=\"javascript:void(0)\" onClick=\"vestibar_flv_window('"+video_file+"', '"+escape(vestibar_getNode('title', i))+"')\"></a>";
				else video_file = "<a class=\"video\" title=\"\u0421\u043c\u043e\u0442\u0440\u0435\u0442\u044c \u0432\u0438\u0434\u0435\u043e\" href=\"javascript:void(0)\" onClick=\"vestibar_video_window('"+video_file+"', '"+escape(vestibar_getNode('title', i))+"')\"></a>";
				outputFirst = vestibar_Replace(outputFirst, "(::Video::)", video_file);
				output = vestibar_Replace(output, "(::Video::)", video_file);
				output2 = vestibar_Replace(output2, "(::Video::)", video_file);
			} else {
				outputFirst = vestibar_Replace(outputFirst, "(::Video::)", "<span class='novideo'></span>");
				output = vestibar_Replace(output, "(::Video::)", "<span class='novideo'></span>");
				output2 = vestibar_Replace(output2, "(::Video::)", "<span class='novideo'></span>");
			}
			
			tag = vestibar_getNode('tag',i);
			
			if(tag=="\u0433\u043b\u0430\u0432\u043d\u0430\u044f") {
				rssBodyFirst.innerHTML = outputFirst;
			} else {
				if(tag=="\u043d\u043e\u0432\u043e\u0441\u0442\u0438 \u0434\u043d\u044f") sclass="news1";
				else if(tag=="\u044d\u043a\u043e\u043d\u043e\u043c\u0438\u043a\u0430") sclass="news2";
				else if(tag=="\u0441\u043f\u043e\u0440\u0442") sclass="news3";
				
				output = vestibar_Replace(output, "(::Class::)", sclass);
				buffer+=output;
				vestibar_news[vestibar_news.length] = "<span class='"+sclass+"'>"+output2+"</span>";
			}
			

		}
		rssBody.innerHTML = buffer;
		rssBody2.innerHTML = buffer2;
	}
	
	vestibar_news_index = 0;
	vestibar_news_show();
}

//=====================================================================================

function vestibar_news_show() {
	document.getElementById("vestibar_other").innerHTML = vestibar_news[vestibar_news_index];
	vestibar_news_index++;
	if(vestibar_news_index>=vestibar_news.length) vestibar_news_index = 0;
	if(tm_s) clearTimeout(tm_s);
	tm_s = setTimeout("vestibar_news_show()", vestibar_shift);