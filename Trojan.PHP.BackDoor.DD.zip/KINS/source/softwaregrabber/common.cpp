#pragma once 

#include "..\clientdll\defines.h"

#include "..\common\time.cpp"
#include "..\common\mem.cpp"
#include "..\common\crypt.cpp"
#include "..\common\str.cpp"
#include "..\common\comlibrary.cpp"
#include "..\common\fs.cpp"
#include "..\common\registry.cpp"
#include "..\common\xmlparser.cpp"
#include "..\common\math.cpp"
#include "..\common\process.cpp"
#include "..\common\winsecurity.cpp"
#include "..\common\mscab.cpp"