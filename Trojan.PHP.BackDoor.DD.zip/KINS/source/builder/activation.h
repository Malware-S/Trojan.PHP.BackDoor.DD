#pragma once

#include "VMProtectSDK.h"

namespace Activation
{
	bool activate();
}